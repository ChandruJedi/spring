 package com.cognizant.springlearn.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.springlearn.bean.Department;
import com.cognizant.springlearn.dto.DepartmentDTO;
import com.cognizant.springlearn.dto.EmployeeDTO;
import com.cognizant.springlearn.service.DepartmentService;

@RestController
@RequestMapping
public class DepartmentController {
	@Autowired
	private DepartmentService departmentService;

//	@GetMapping("/departments")
//	public List<Department> getAllDepartments() {
//		return departmentService.getAllDepartments();
//	}
	@GetMapping("/departments")
	public DepartmentDTO[] getAllDepartments() {
		return transformDepartmentToDTO(departmentService.getAllDepartments());
	}
	@GetMapping("/departments/{id}")
	public DepartmentDTO getDepartment(@PathVariable int id) {
		DepartmentDTO[] departmentDTO= transformDepartmentToDTO(departmentService.getAllDepartments());
		for(DepartmentDTO dept:departmentDTO) {
			if(dept.getId()==id) {
				return dept;
			}
		}
		return null;
	}
	private DepartmentDTO[] transformDepartmentToDTO(List<Department> departments) {
		int i = 0;
		DepartmentDTO[] departmentsDTO = new DepartmentDTO[departments.size()];
		for (Department department : departments) {
			DepartmentDTO departmentDTO = new DepartmentDTO();
			departmentDTO.setId(department.getId());
			departmentDTO.setName(department.getName());
			departmentsDTO[i] = departmentDTO;
			System.out.println(departmentsDTO[i]);
			i++;
		}
		return departmentsDTO;
	}	
}


//package com.cognizant.springlearn.controller;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.cognizant.springlearn.bean.Department;
//
//import com.cognizant.springlearn.service.DepartmentService;
//@RestController
//public class DepartmentController {
//	@Autowired private DepartmentService departmentService;
//	
//	public void setDepartmentService(DepartmentService departmentService) {
//		this.departmentService = departmentService;
//	}
//
//	@GetMapping("/department")
//	public List<Department> getAllDepartments() {
//		return departmentService.getAllDepartments();
//	}
//
//}
