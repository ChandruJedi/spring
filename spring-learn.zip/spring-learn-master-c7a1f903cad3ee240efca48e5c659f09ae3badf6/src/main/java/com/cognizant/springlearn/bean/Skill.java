package com.cognizant.springlearn.bean;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

@Entity
@Table(name="skill")
public class Skill {
	private static final Logger LOGGER=LoggerFactory.getLogger(Skill.class);
	@NotNull
	@Positive
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="sk_id")
	private int id;
	@NotNull
	@Size(min=1, max=30, message="Country code should be above 1 and below 30 characters")
	@Column(name="sk_name")
	private String name;
	@ManyToMany(mappedBy = "skillList",fetch=FetchType.EAGER)
//	@JsonIgnore
//	@JsonBackReference
//	@JsonManagedReference
//	@JsonIdentityInfo(
//	generator = ObjectIdGenerators.PropertyGenerator.class, 
//	property = "id")
	private Set<Employee> employeeList;
	@Override
	public String toString() {
		return "Skill [id=" + id + ", name=" + name + "]";
	}
	public Skill() {
		super();
		// TODO Auto-generated constructor stub
		LOGGER.debug("skill cons");
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Set<Employee> getEmployeeList() {
		return employeeList;
	}
	public void setEmployeeList(Set<Employee> employeeList) {
		this.employeeList = employeeList;
	}
	
}
