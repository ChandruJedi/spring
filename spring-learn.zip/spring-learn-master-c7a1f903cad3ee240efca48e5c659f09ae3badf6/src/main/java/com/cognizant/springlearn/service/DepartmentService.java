package com.cognizant.springlearn.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


import com.cognizant.springlearn.bean.Employee;
import com.cognizant.springlearn.bean.SpringLearnConstants;
import com.cognizant.springlearn.dto.DepartmentDTO;
import com.cognizant.springlearn.bean.Department;
import com.cognizant.springlearn.repository.DepartmentRepository;

//@Component
@Service
public class DepartmentService {
	@Autowired private DepartmentRepository departmentRepository;
//	@Autowired private DepartmentDTO departmentDTO;
//	public void setDepartmentDao(DepartmentDao departmentDao) {
//		this.departmentDao = departmentDao;
//	}

	public List<Department> getAllDepartments() {
		return departmentRepository.findAll();
	}
	@Transactional
	public Department getDepartment(int id) {
		return departmentRepository.findById(id).get();
	}
	
}
