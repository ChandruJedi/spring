/**
 * @author 805972
 *
 */
package com.cognizant.springlearn.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.springlearn.bean.Skill;


/**
 * @author 805972
 *
 */
@Repository
public interface SkillRepository extends JpaRepository<Skill,Integer> {

}
