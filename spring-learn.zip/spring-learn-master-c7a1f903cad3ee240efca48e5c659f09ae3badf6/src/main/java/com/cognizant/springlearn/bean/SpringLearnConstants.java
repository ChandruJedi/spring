package com.cognizant.springlearn.bean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cognizant.springlearn.SpringLearnApplication;

public class SpringLearnConstants {
	public static final Logger LOGGER= LoggerFactory.getLogger(SpringLearnApplication.class);
}
