/**
 * @author 805972
 *
 */
package com.cognizant.springlearn.service;

import static org.mockito.Mockito.when;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.cognizant.springlearn.bean.Role;
import com.cognizant.springlearn.bean.User;
import com.cognizant.springlearn.repository.UserRepository;
import com.cognizant.springlearn.security.AppUserDetailsService;

/**
 * @author 805972
 *
 */
@SpringBootTest
public class UserDetailsServiceMockTest {
	private static final Logger LOGGER = LoggerFactory.getLogger(UserDetailsService.class);

	@Test
	public void mockTestLoadUserByUsername() {
		LOGGER.info("Start");
		UserRepository repository = Mockito.mock(UserRepository.class);
		when(repository.findByUsername("usr")).thenReturn(createUser());
		UserDetailsService service = new AppUserDetailsService(repository); // repository refers to the mock repository
																			// created
		UserDetails user = service.loadUserByUsername("usr");
		String expected = "$2a$10$R/lZJuT9skteNmAku9Y7aeutxbOKstD5xE5bHOf74M2PHZipyt3yK";
		assertEquals(expected, user.getPassword());
		LOGGER.info("End");
	}

	@Test
	public void mockTestLoadByUserNameWithUserNull() {
		LOGGER.info("Start");
		UserRepository repository = Mockito.mock(UserRepository.class);
		when(repository.findByUsername("user")).thenReturn(null);
		UserDetailsService service = new AppUserDetailsService(repository);
		try {
			UserDetails user = service.loadUserByUsername("usr1");
			LOGGER.debug("user:{}", user);
		} catch (UsernameNotFoundException e) {
			LOGGER.error("User not found", e);
			assertTrue(true);
			return;
		}
		assertFalse(true);
		LOGGER.info("End");
	}

	private User createUser() {
		User user = new User();
		user.setId(1);
		user.setPassword("$2a$10$R/lZJuT9skteNmAku9Y7aeutxbOKstD5xE5bHOf74M2PHZipyt3yK");

		Role role = new Role();
		role.setId(1);
		role.setName("USER");
		Set<Role> roles = new HashSet<>();
		roles.add(role);
		user.setRoleList(roles);

		return user;
	}
}

