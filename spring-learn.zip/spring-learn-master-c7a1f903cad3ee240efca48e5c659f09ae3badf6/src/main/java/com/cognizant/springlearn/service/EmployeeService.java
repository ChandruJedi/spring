package com.cognizant.springlearn.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.cognizant.springlearn.SpringLearnApplication;
import com.cognizant.springlearn.bean.Employee;
import com.cognizant.springlearn.bean.SpringLearnConstants;


import com.cognizant.springlearn.repository.EmployeeRepository;
import com.cognizant.springlearn.service.exception.EmployeeNotFoundException;


//@Component
@Service
//@ResponseStatus(value=HttpStatus.FORBIDDEN)
public class EmployeeService extends EmployeeNotFoundException   {
	public static final Logger LOGGER= LoggerFactory.getLogger(SpringLearnApplication.class);
	//public EmployeeNotFoundException HttpStatus code 
	@Autowired private EmployeeRepository employeeRepository;
//	@Autowired
//	public void setEmployeeDao(EmployeeDao employeeDao) {
//		SpringLearnConstants.LOGGER.debug("Inside Employee Service");
//		this.employeeDao = employeeDao;
//	}
	@Transactional
	public Employee get(int id) {
		return employeeRepository.findById(id).get();
	}
	public List<Employee> getAllEmployee(){
//		return employeeDao.getAllEmployees();
		List<Employee> employees=employeeRepository.findAll();
		return employees;
	}
	
	public Employee getEmployee(int id) {
		Employee employee=employeeRepository.findById(id).get();
		LOGGER.info(employee.toString());
		return employee;
	}
	public void updateEmployee(Employee employee) throws EmployeeNotFoundException {
		LOGGER.info(employee.toString());
		employeeRepository.save(employee);
//		employeeDao.updateEmployee(employee);
	}
	
	public void addEmployee(Employee employee) throws EmployeeNotFoundException {
		LOGGER.info(employee.toString());
		employeeRepository.save(employee);
//		employeeDao.updateEmployee(employee);
	}
	public void deleteEmployee(int id) throws EmployeeNotFoundException {
		employeeRepository.deleteById(id);		
	}
}
