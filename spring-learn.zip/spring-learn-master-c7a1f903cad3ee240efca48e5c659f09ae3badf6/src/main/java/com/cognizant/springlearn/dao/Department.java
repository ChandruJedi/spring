/**
 * 
 */
package com.cognizant.springlearn.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * @author 805972
 *
 */
public class Department {
	private int id;
	private String name;
	private static final Logger LOGGER = LoggerFactory.getLogger(Department.class);
	public Department() {
		super();
		LOGGER.debug("Super Constructor");
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Department [id=" + id + ", name=" + name + "]";
	}
	
}
