package com.cognizant.springlearn.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.cognizant.springlearn.bean.Country;
import com.cognizant.springlearn.repository.CountryRepository;
import com.cognizant.springlearn.service.exception.CountryNotFoundException;

//@Service
//public class CountryService {
//	public Country getCountry(String code) throws CountryNotFoundException{
//		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
//		ArrayList<Country> countries =context.getBean("countryList", ArrayList.class);
//		System.out.println(countries.size());
//		Country filteredCountry = countries.parallelStream().filter(country -> country.getCode().equalsIgnoreCase(code)).findFirst().orElseThrow(() -> new CountryNotFoundException());
//		return filteredCountry;
//	}
//}
@Service
public class CountryService {
	@Autowired CountryRepository countryRepository;
	@Transactional
	public List<Country> getAllCountries(){
		return countryRepository.findAll();
		 
	}
	 @Transactional
	 public Country findCountryByCode(String countryCode) throws CountryNotFoundException {
		 Optional<Country> result = countryRepository.findById(countryCode);
		 if (!result.isPresent()) {
			 throw new CountryNotFoundException();
		 } else {
			 Country country = result.get();
			 return country;
		 }	
	}
	 @Transactional
	 public void addCountry(Country country) {
		 countryRepository.save(country);
	 }
	 @Transactional
	 public void updateCountry(Country country) throws CountryNotFoundException {
		 Country country2=findCountryByCode(country.getCode());
		 country.setName(country.getName());
		 countryRepository.save(country2);
		 
	 }
	 @Transactional
	 public void deleteCountry(String id) throws CountryNotFoundException {
		 Country country=findCountryByCode(id);
		 countryRepository.delete(country);
	 }
	 @Transactional
	 public List<Country> findByNameContaining(String id) throws CountryNotFoundException {
		 return countryRepository.findByNameContaining(id);
	 }
	 @Transactional
	 public List<Country> findByNameContainingOrderByName(String id) throws CountryNotFoundException {
		return countryRepository.findByNameContainingOrderByName(id);
	 }
	 @Transactional
	 public List<Country> findByNameStartingWithOrderByName(String id) throws CountryNotFoundException {
		return countryRepository.findByNameStartingWithOrderByName(id);
	 }
}
