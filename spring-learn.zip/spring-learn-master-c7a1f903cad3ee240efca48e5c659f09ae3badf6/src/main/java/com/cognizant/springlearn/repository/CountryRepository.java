/**
 * @author 805972
 *
 */
package com.cognizant.springlearn.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.springlearn.bean.Country;



/**
 * @author 805972
 *
 */
@Repository
public interface CountryRepository extends JpaRepository<Country, String> {
	List<Country> findByNameContaining(String name);
	List<Country> findByNameContainingOrderByName(String name);
	List<Country> findByNameStartingWithOrderByName(String name);
}
