package com.cognizant.springlearn.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.springlearn.SpringLearnApplication;
import com.cognizant.springlearn.bean.Employee;
import com.cognizant.springlearn.bean.Skill;
import com.cognizant.springlearn.dto.DepartmentDTO;
import com.cognizant.springlearn.dto.EmployeeDTO;
import com.cognizant.springlearn.dto.SkillDTO;
import com.cognizant.springlearn.repository.EmployeeRepository;
import com.cognizant.springlearn.service.EmployeeService;
import com.cognizant.springlearn.service.exception.EmployeeNotFoundException;

/*@Component*/
//@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("employees")
public class EmployeeController {
	@Autowired private EmployeeService employeeService;
	public static final Logger LOGGER= LoggerFactory.getLogger(SpringLearnApplication.class);
//	@Autowired
//	public void setEmployeeService(EmployeeService employeeService) {
//		this.employeeService = employeeService;
//		LOGGER.debug("Employee Controller Constructor");
//	}

//	@GetMapping()
//	public List<Employee> getAllEmployees() {
//		return employeeService.getAllEmployee();
//
//	}
	 private EmployeeDTO[] transformEmployeeToDTO(List<Employee> employees) {
		 EmployeeDTO[] employeesDTO = new EmployeeDTO[employees.size()];
		 int i = 0;
		 for (Employee employee: employees) {
			 EmployeeDTO employeeDTO =new EmployeeDTO();
			 employeeDTO.setId(employee.getId());
				employeeDTO.setName(employee.getName());
				employeeDTO.setPermanent(employee.isPermanent());
				employeeDTO.setDateOfBirth(employee.getDateOfBirth());
				employeeDTO.setSalary(employee.getSalary());
				DepartmentDTO departmentDTO = new DepartmentDTO();
				departmentDTO.setId(employee.getDepartment().getId());
				departmentDTO.setName(employee.getDepartment().getName());
				employeeDTO.setDepartment(departmentDTO);
				for (Skill skill : employee.getSkillList()) {
					SkillDTO skillDTO = new SkillDTO();
					skillDTO.setId(skill.getId());
					skillDTO.setName(skill.getName());
					if (employeeDTO.getSkillList() == null) {
						employeeDTO.setSkillList(new HashSet<SkillDTO>());
					}
					employeeDTO.getSkillList().add(skillDTO);
				}
				employeesDTO[i] = employeeDTO;
				i++;
			 
		 }
		 return employeesDTO;
	 }
	 @GetMapping
	 public EmployeeDTO[] getAllEmployee(){
	 	return transformEmployeeToDTO(employeeService.getAllEmployee());
	 }
		 
	 
	@PutMapping
	public void updateEmployee(@RequestBody @Valid Employee employee) throws EmployeeNotFoundException {
		LOGGER.debug(employee.toString());
		employeeService.updateEmployee(employee);
	}
	@PostMapping
	public void addEmployee(@RequestBody @Valid Employee employee) throws EmployeeNotFoundException {
		employeeService.addEmployee(employee);
	}
	@GetMapping("/{id}")
	public EmployeeDTO getEmployee(@PathVariable int id) {
		EmployeeDTO[] employeeDto = transformEmployeeToDTO(employeeService.getAllEmployee());
		for(EmployeeDTO emp:employeeDto) {
			if(emp.getId()==id) {
				return emp;
			}
		}
		return null;
	}
	@DeleteMapping("/{id}")
	public void deleteEmployee(@PathVariable int id) throws EmployeeNotFoundException {
		employeeService.deleteEmployee(id);
	}
//	@PutMapping
//	public void updateEmployee(@RequestBody @Valid Employee employee) throws EmployeeNotFoundException {
//		employeeService.updateEmployee(employee);
//	}
//	
}


