package com.cognizant.springlearn.controller;

import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



import com.cognizant.springlearn.SpringLearnApplication;
import com.cognizant.springlearn.service.CountryService;
import com.cognizant.springlearn.service.EmployeeService;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@RestController
public class AuthenticationController {
	@Autowired private EmployeeService employeeService;
	public static final Logger LOGGER= LoggerFactory.getLogger(SpringLearnApplication.class);
	@GetMapping("/authenticate")
	Map<String, String> authenticate(@RequestHeader("Authorization") String authHeader){
		LOGGER.info("authen start");
		LOGGER.debug(authHeader);
		HashMap<String, String> data=new HashMap<String, String>();
		String data1=getUser(authHeader);
		data.put("token",generateJwt(data1));
		LOGGER.info("authen end");
		return data;
	}
	
	
	 private String getUser(String authHeader) {
		 LOGGER.debug("getUser start");
		 String encodedCredentials=authHeader.split(" ")[1];	 
		 String data=new String(Base64.getDecoder().decode(encodedCredentials));
		 LOGGER.debug("getUser end");
		 return data;
	 }
	 
	 private String generateJwt(String user) {
		 JwtBuilder builder = Jwts.builder();
	        builder.setSubject(user);
	        builder.setIssuedAt(new Date());
	        builder.setExpiration(new Date((new Date()).getTime() + 1200000));
	        builder.signWith(SignatureAlgorithm.HS256, "secretkey");
	        String token = builder.compact();
	        return token;
	 }

	
	
	

}
