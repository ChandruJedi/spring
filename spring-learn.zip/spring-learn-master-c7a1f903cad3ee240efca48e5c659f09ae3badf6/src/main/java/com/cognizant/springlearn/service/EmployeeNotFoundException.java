package com.cognizant.springlearn.service;

public class EmployeeNotFoundException {

}
