package com.cognizant.springlearn.bean;

import java.util.Arrays;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.PositiveOrZero;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.ISBN;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;


@Entity
@Table(name = "employee")
public class Employee {
	private static final Logger LOGGER=LoggerFactory.getLogger(Employee.class);
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "em_id")
	@NotNull
	@Positive
	private int id;
	@Column(name = "em_name")
	@NotNull
	@Size(min=1, max=30, message="Name should be above 4 and below 30 characters")
	private String name;
	@NotNull
	@Min(0)
	@Column(name = "em_salary")
	private double salary;
	@NotNull
	@Column(name = "em_permanent")
	private boolean permanent;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy")
	@Column(name = "em_date_of_birth")
	private Date dateOfBirth;
	@ManyToOne
	@JoinColumn(name = "em_dp_id")
	@JsonIdentityInfo(
	generator = ObjectIdGenerators.PropertyGenerator.class, 
	property = "id")
	private Department department; 
	@ManyToMany(fetch = FetchType.EAGER)
//	@ManyToMany
    @JoinTable(name = "employee_skill",
        joinColumns = @JoinColumn(name = "es_em_id"), 
        inverseJoinColumns = @JoinColumn(name = "es_sk_id"))
//	@JsonManagedReference
//	@JsonIdentityInfo(
//	generator = ObjectIdGenerators.PropertyGenerator.class, 
//	property = "id")
	private Set<Skill> skillList;
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
		LOGGER.debug("HII");
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	
	
@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", permanent=" + permanent
				+ ", dateOfBirth=" + dateOfBirth + ", department=" + department + ", skills=" + skillList + "]";
	}
	//	public Skill[] getSkills() {
//		return skills;
//	}
//	public void setSkills(Skill[] skills) {
//		this.skills = skills;
//	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public boolean isPermanent() {
		return permanent;
	}
	public void setPermanent(boolean permanent) {
		this.permanent = permanent;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Set<Skill> getSkillList() {
		return skillList;
	}
	public void setSkillList(Set<Skill> skillList) {
		this.skillList = skillList;
	}
	

}
