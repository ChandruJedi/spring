package com.cognizant.springlearn.dto;

import java.util.Set;


import com.cognizant.springlearn.bean.Employee;

public class SkillDTO {
	private int id;
	private String name;
	    private Set<EmployeeDTO> employeeList;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Skill [id=" + id + ", name=" + name + "]";
	}
	public Set<EmployeeDTO> getEmployeeList() {
		return employeeList;
	}
	public void setEmployeeList(Set<EmployeeDTO> employeeList) {
		this.employeeList = employeeList;
	}


}
