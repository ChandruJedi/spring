package com.cognizant.springlearn;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cognizant.springlearn.bean.Country;
import com.cognizant.springlearn.controller.EmployeeController;
import com.cognizant.springlearn.service.CountryService;
import com.cognizant.springlearn.service.EmployeeService;
import com.cognizant.springlearn.service.exception.CountryNotFoundException;

@SpringBootApplication
public class SpringLearnApplication {
	public static final Logger LOGGER= LoggerFactory.getLogger(SpringLearnApplication.class);
//	private static CountryService countryService;
//	private static EmployeeService employeeService;
	public static void main(String[] args) throws ParseException, CountryNotFoundException {
		SpringApplication.run(SpringLearnApplication.class, args);
//		ApplicationContext context = SpringApplication.run(SpringLearnApplication.class, args);
//		countryService =  context.getBean(CountryService.class);
//		displayDate();
//		displayCountry();
//		getEmployeeController();
//		displayCountries();
//		getAllCountries();
//		findCountryByCode();
//		addCountry();
//		findByNameContaining();
	}
	
//	 private static void displayCountry() {
//		 ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
//		 Country country = (Country) context.getBean("country", Country.class);
//		 Country anotherCountry = context.getBean("country", Country.class);
//		 LOGGER.debug("Country : {}", country.toString());
//	}

//	static void displayDate() throws ParseException {
//		 LOGGER.info("START");
//		 ApplicationContext context = new ClassPathXmlApplicationContext("date-format.xml");
//		 SimpleDateFormat format = context.getBean("dateFormat", SimpleDateFormat.class);
//		 Date date=format.parse("31/12/2018");
//		 LOGGER.debug(date.toString());
////		 System.out.println(date.toString());
//		 LOGGER.info("END");
//	}
//	static void getEmployeeController() {
//		 ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml");
//		 EmployeeController employeeController = (EmployeeController)context.getBean("employeeController",EmployeeController.class);
//		 LOGGER.debug("IN MAIN CLASS");
//	}
//	 static void displayCountries(){
//			
//			ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
//			ArrayList<Country> countries =context.getBean("countryList", ArrayList.class);
//		
//			for(Country country:countries) {
//				LOGGER.debug(country.toString());
//			}
//		
//		//	System.out.println(country);
//			
//			
//		}
//	 public static List<Country> getAllCountries(){
//		 return countryService.getAllCountries();
//	 }
//	 
//	 public static void findCountryByCode() throws CountryNotFoundException{
//		 countryService.findCountryByCode("IN");
//	 }
//	 public static void addCountry() {
//		 Country country=new Country();
//		 country.setCode("PC");
//		 country.setName("Chandru");
//		 LOGGER.debug(country.toString());
//		 countryService.addCountry(country);
//	 }
//	 public static List<Country> findByNameContaining() throws CountryNotFoundException{
//		 return countryService.findByNameContaining("ch");
//	 }
}
