//package com.cognizant.springlearn.dao;
//
//import java.awt.List;
//import java.util.ArrayList;
//
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.support.ClassPathXmlApplicationContext;
//import org.springframework.stereotype.Component;
//
//import com.cognizant.springlearn.bean.Employee;
//
//import com.cognizant.springlearn.bean.SpringLearnConstants;
//import com.cognizant.springlearn.service.exception.EmployeeNotFoundException;
//
//@Component
//public class EmployeeDao {
//	static ArrayList<Employee> EMPLOYEE_LIST;
//	int empId;
//	public EmployeeDao() {
//	// TODO Auto-generated constructor stub
//	SpringLearnConstants.LOGGER.debug("Inside Employee DAO");
//	ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml");
//	EMPLOYEE_LIST = context.getBean("employeeList",ArrayList.class);
//	for(Employee employee:EMPLOYEE_LIST) {
//		SpringLearnConstants.LOGGER.debug(employee.toString());
//	}}
//	public Employee getEmployee(int id) {
//		Employee emp=EMPLOYEE_LIST.stream().filter(employee->employee.getId()==id).findFirst().orElse(null);
//		return emp;
//	}
//
//	public ArrayList<Employee> getAllEmployees(){
//		return EMPLOYEE_LIST;
//	}
//	
//	public void updateEmployee(Employee employee) throws EmployeeNotFoundException {
//
//		int c=0;
//		for(Employee employeeObj:EMPLOYEE_LIST) {
//			if(employeeObj.getId()==employee.getId()) {
//				employeeObj.setName(employee.getName());
//				c++;
//			}
//		}
//		if(c==0) {
//			throw new EmployeeNotFoundException();
//		}
//
//	}
//	
//	public void deleteEmployee(int id) throws EmployeeNotFoundException{
//		int a=0;
//		for(Employee employee2: EMPLOYEE_LIST) {
//			if(employee2.getId()==id) {
//				EMPLOYEE_LIST.remove(employee2);
//			}
//		}
//		if(a==0) {
//			throw new EmployeeNotFoundException();
//		}
//	}
//}
