//package com.cognizant.springlearn.dao;
//
//import java.util.ArrayList;
//
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.support.ClassPathXmlApplicationContext;
//import org.springframework.stereotype.Component;
//
//import com.cognizant.springlearn.bean.Department;
//import com.cognizant.springlearn.bean.SpringLearnConstants;
//
//@Component
//public class DepartmentDao {
//	static ArrayList<Department> DEPARTMENT_LIST;
//	public DepartmentDao() {
//		SpringLearnConstants.LOGGER.debug("Inside Department Dao Constructor");
//		ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml");
//		DEPARTMENT_LIST=context.getBean("departmentList",ArrayList.class);
//		for(Department department:DEPARTMENT_LIST) {
//			SpringLearnConstants.LOGGER.debug(department.toString());
//		}
//		
//		
//	}
//	
//	public ArrayList<Department> getAllDepartments(){
//		return DEPARTMENT_LIST;
//	}
//}
